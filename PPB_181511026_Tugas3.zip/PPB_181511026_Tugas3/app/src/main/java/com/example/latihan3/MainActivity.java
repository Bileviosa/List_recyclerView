package com.example.latihan3;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;


public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        MyListData[] myListData = new MyListData[] {
                new MyListData("Tiket Kereta Api Eko    180,000.00"),
                new MyListData("PDAM bulan Juni         25,000.00"),
                new MyListData("Listrik bulan Juni      60,000.00"),
                new MyListData("Makan Enak dan Mahal    80,000.00"),
                new MyListData("Kuota Indosat 6 GB+     75,000.00"),
                new MyListData("PDAM bulan Juli         25,000.00"),
                new MyListData("Listrik bulan Juli      60,000.00"),
                new MyListData("Makan Enak dan Mahal    80,000.00"),
                new MyListData("Kuota Indosat 6 GB+     75,000.00"),
                new MyListData("PDAM bulan Agustus      25,000.00"),
                new MyListData("Listrik bulan Agustus   60,000.00"),
                new MyListData("Makan Enak dan Mahal    80,000.00"),
                new MyListData("Kuota Indosat 6 GB+     75,000.00"),
        };

        RecyclerView recyclerView = (RecyclerView) findViewById(R.id.recyclerView);
        MyListAdapter adapter = new MyListAdapter(myListData);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(adapter);
    }
}
